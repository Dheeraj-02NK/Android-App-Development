package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button button1, button2, button3, button4, button5, button6, button7, button8, button9, button0;
    Button btnadd, btnsub, btnmul, btndiv;
    Button btndot, btnclr, eq;
    EditText result;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1=(Button)findViewById(R.id.button1);
        button1.setOnClickListener(this);

        button2=(Button)findViewById(R.id.button2);
        button2.setOnClickListener(this);

        button3=(Button)findViewById(R.id.button3);
        button3.setOnClickListener(this);

        button4=(Button)findViewById(R.id.button4);
        button4.setOnClickListener(this);

        button5=(Button)findViewById(R.id.button5);
        button5.setOnClickListener(this);

        button6=(Button)findViewById(R.id.button6);
        button6.setOnClickListener(this);

        button7=(Button)findViewById(R.id.button7);
        button7.setOnClickListener(this);

        button8=(Button)findViewById(R.id.button8);
        button8.setOnClickListener(this);

        button9=(Button)findViewById(R.id.button9);
        button9.setOnClickListener(this);

        button0=(Button)findViewById(R.id.button0);
        button0.setOnClickListener(this);

        btnadd=(Button)findViewById(R.id.btnadd);
        btnadd.setOnClickListener(this);

        btnsub=(Button)findViewById(R.id.btnsub);
        btnsub.setOnClickListener(this);

        btnmul=(Button)findViewById(R.id.btnmul);
        btnmul.setOnClickListener(this);

        btndiv=(Button)findViewById(R.id.btndiv);
        btndiv.setOnClickListener(this);

        btndot=(Button)findViewById(R.id.btndot);
        btndot.setOnClickListener(this);

        btnclr=(Button)findViewById(R.id.btnclr);
        btnclr.setOnClickListener(this);

        eq=(Button)findViewById(R.id.eq);
        eq.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if(v.equals(button1))
            result.append("1");
        if(v.equals(button2))
            result.append("2");
        if(v.equals(button3))
            result.append("3");
        if(v.equals(button4))
            result.append("4");
        if(v.equals(button5))
            result.append("5");
        if(v.equals(button6))
            result.append("6");
        if(v.equals(button7))
            result.append("7");
        if(v.equals(button8))
            result.append("8");
        if(v.equals(button9))
            result.append("9");
        if(v.equals(button0))
            result.append("0");
        if(v.equals(btndot))
            result.append(".");
        if(v.equals(btnclr))
            result.append("");
        if(v.equals(btnadd))
            result.append("+");
        if(v.equals(btnsub))
            result.append("-");
        if(v.equals(btnmul))
            result.append("*");
        if(v.equals(btndiv))
            result.append("/");

        if (v.equals(eq)) {
            try {
                String data = result.getText().toString();
                if (data.contains("*")) {

                    String[] operands = data.split(Pattern.quote("*"));
                    if (operands.length == 2) {
                        double operand1 = Double.parseDouble(operands[0]);
                        double operand2 = Double.parseDouble(operands[1]);
                        double res = operand1 * operand2;
                        result.setText(String.valueOf(res));
                    }
                } else {
                    Toast.makeText(getBaseContext(), "invalid input", Toast.LENGTH_SHORT).show();
                }
                if (data.contains("/")) {

                    String[] operands = data.split(Pattern.quote("*"));
                    if (operands.length == 2) {
                        double operand1 = Double.parseDouble(operands[0]);
                        double operand2 = Double.parseDouble(operands[1]);
                        double res = operand1 / operand2;
                        result.setText(String.valueOf(res));
                    }
                } else {
                    Toast.makeText(getBaseContext(), "invalid input", Toast.LENGTH_SHORT).show();
                }
                if (data.contains("+")) {

                    String[] operands = data.split(Pattern.quote("*"));
                    if (operands.length == 2) {
                        double operand1 = Double.parseDouble(operands[0]);
                        double operand2 = Double.parseDouble(operands[1]);
                        double res = operand1 + operand2;
                        result.setText(String.valueOf(res));
                    }
                } else {
                    Toast.makeText(getBaseContext(), "invalid input", Toast.LENGTH_SHORT).show();
                }
                if (data.contains("-")) {

                    String[] operands = data.split(Pattern.quote("*"));
                    if (operands.length == 2) {
                        double operand1 = Double.parseDouble(operands[0]);
                        double operand2 = Double.parseDouble(operands[1]);
                        double res = operand1 - operand2;
                        result.setText(String.valueOf(res));
                    }
                } else {
                    Toast.makeText(getBaseContext(), "invalid input", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception E) {
                Toast.makeText(getBaseContext(), "invalid input", Toast.LENGTH_SHORT).show();
            }
        }
    }
}